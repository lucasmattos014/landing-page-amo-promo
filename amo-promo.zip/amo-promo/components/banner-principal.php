<div class="banner-principal" style="background-image: url(img/banner.jpg);">

    <div class="container">

        <div class="banner1">
            <h1 class="fadeInDown">Tranquilidade para viver mais</h1>
            <p class="fadeInDown responsive">Viva mais e melhor com os benefícios<br> que um serguro de vida te oferece</p>
        </div>

        <div class="banner2">
            <p class="desktop fadeInTop">Viva mais e melhor com os benefícios<br> que um serguro de vida te oferece</p>

            <a href="https://www.segurospromo.com.br/seguro-de-vida/cotacao/" target="_blank">
                <button class="fadeInTop" id="primary_button">Faça sua cotação</button>
            </a>
        </div>

    </div>

</div>