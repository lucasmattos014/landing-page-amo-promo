<div id="mySidenav" class="sidenav menunav menu">
    <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>

    <div style="margin: auto 0;">
            <ul>
            <a href="https://www.segurospromo.com.br/seguro-de-vida" target="blank">
                    <li>Seguro de Vida</li>
                </a>
                <a href="https://www.segurospromo.com.br/multi-trip/" target="_blank">
                    <li>Multi-trip</li>
                </a>
                <a href="https://www.segurospromo.com.br/atendimento/" target="_blank">
                    <li>FAQ</li>
                </a>
                <a href="https://www.parceirospromo.com.br/" target="_blank">
                    <li>Afiliados</li>
                </a>
                <a href="https://www.segurospromo.com.br/blog/" target="_blank">
                    <li>Blog</li>
                </a>
            </ul>
        </div>

</div>