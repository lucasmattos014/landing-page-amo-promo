<div class="seguros">

    <div class="container">

        <h2 class="fadeInDown desktop">Mas por que ter um seguro de vida?</h2>

        <div class="col-1-2 mobile-reverse">

            <div>

                <h2 class="fadeInDown responsive">Por que ter um seguro de vida?</h2>

                <?php include('api/duvidas_api.php'); ?>
                <br><br>
                <a href="https://www.segurospromo.com.br/seguro-de-vida/cotacao/" target="_blank">
                    <button class="fadeInUp responsive" id="primary_button">Faça sua cotação</button>
                </a>

            </div>

            <div class="text-seguro">

                <div class="right"><img class="fadeInRight" src="img/seguro.png" alt="Seguro"></div>

                <a href="https://www.segurospromo.com.br/seguro-de-vida/cotacao/" target="_blank">
                    <button class="fadeInRight desktop" id="primary_button">Faça sua cotação</button>
                </a>

            </div>

        </div>

    </div>

</div>