<div class="planos">

    <div class="container col-2-1 mobile-reverse">

        <div>

            <img class="uptotop" src="img/desktop-phone.png" alt="Desktop e Smartphone">

            <a href="https://www.segurospromo.com.br/seguro-de-vida/cotacao/" target="_blank">
                <button class="fadeInDown responsive" id="primary_button">Faça sua cotação</button>
            </a>

        </div>

        <div style="margin: auto 0;">

            <h2 class="fadeInRight">Planos personalizados <br>e sem burocracia</h2>
            <p class="fadeInRight"><span>1.</span> Informe seus dados</p>
            <p class="fadeInRight"><span>2.</span> Descubra o plano ideal para o seu perfil</p>
            <p class="fadeInRight"><span>3.</span> Escolha sua forma de pagamento e contrate 100% online</p>

            <h3 class="fadeInRight">Pronto! Agora você e sua família têm todos os benefícios de viver com segurança total</h3>

            <div style="text-align: center;">

                <a href="https://www.segurospromo.com.br/seguro-de-vida/cotacao/" target="_blank">
                    <button class="fadeInRight" class="desktop" id="primary_button">Faça sua cotação</button>
                </a>

            </div>

        </div>

    </div>

</div>